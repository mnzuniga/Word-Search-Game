# letters must always be different, do not give one single set.
# make sure it's possible to actually make words
# be able to make at least one 9 letter word
# take a 9 letter word from the list ?

#make a high score system ????
#create another file.. scores.txt opened for writing 



import os
letters = ["a", "b", "c", "o", "e"]
points = 0

#while True:
#    os.system("clear")
#    print(letters)
#    print("Total points:", points)
#    word = input("Enter a word (-1 to stop))")
#    if word == "-1":
#        break
#    points += len(word)

#f = open("scores.txt", "r") 
#save all prev high scores
#determine if it must be updated
#if so, update


#read high scores , at end of game , see if scores have to be updated 


sounda
# sampled
# asd
# ablesd
# asda
# sound